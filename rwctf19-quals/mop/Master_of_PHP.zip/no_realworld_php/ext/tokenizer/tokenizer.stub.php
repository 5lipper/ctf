<?php

/** @return array|false */
function token_get_all(string $source, int $flags = 0) {}

function token_name(int $token): string {}
