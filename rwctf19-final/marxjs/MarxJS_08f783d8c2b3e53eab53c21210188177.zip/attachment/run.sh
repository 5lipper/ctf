#!/bin/bash

unitd --user ctf --group ctf;
# waiting for mongodb
sleep 5;
curl -X PUT --data-binary @unit.config.json --unix-socket /var/run/control.unit.sock http://localhost/config/
echo -e "\n!!!!!!!!!!!!!!!!!! Server Ready Perfectly !!!!!!!!!!!!!!!!\n"
tail -F /var/log/unit.log
