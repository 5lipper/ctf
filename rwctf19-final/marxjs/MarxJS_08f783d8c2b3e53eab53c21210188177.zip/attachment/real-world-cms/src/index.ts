#!/usr/bin/env node
import 'source-map-support/register';

// std
// 3p
import { createServer, IncomingMessage, ServerResponse } from 'unit-http';
require('http').ServerResponse = ServerResponse;
require('http').IncomingMessage = IncomingMessage;
import {createAndInitApp} from '@foal/core';
import {createConnection} from 'typeorm';
// App
import { AppController } from './app/app.controller';
import {createMiddleWare} from './scripts/create-middleware';

async function main() {
  const MiddleWares = createMiddleWare();
  await createConnection();
  const app = await createAndInitApp(AppController, { preMiddlewares: MiddleWares });
  const httpServer = createServer(app).listen();
}

main()
    .catch(err => { console.error(err); process.exit(1); });
