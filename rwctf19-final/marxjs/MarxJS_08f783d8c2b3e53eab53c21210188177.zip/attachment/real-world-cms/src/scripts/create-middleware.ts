import {json, urlencoded} from 'express';
const filter = require('content-filter');

export function createMiddleWare() { return [ json(), urlencoded({extended: true}), filter() ]; }
