import {Context, controller, dependency, generateToken, Get, HttpResponseOK, render, Session} from '@foal/core';
import {getMongoRepository} from 'typeorm';
// tslint:disable-next-line:max-line-length
import { AdminController, IndexController, ResetpassController, SigninController, SignoutController, SignupController } from './controllers';
import { User } from './entities';

export class AppController {
  subControllers = [
    controller('/', IndexController),
    controller('/signup', SignupController),
    controller('/signin', SigninController),
    controller('/signout', SignoutController),
    controller('/resetpass', ResetpassController),
    controller('/admin', AdminController),
  ];
  async init() {
      try {
        await getMongoRepository(User).clear();
      } catch (e) {
        console.log(e);
      }
      const user = new User();
      user.email = 'admin@realworldctf.com';
      user.isAdmin = true;
      const password = await generateToken();
      await user.setPassword(password);
      await getMongoRepository(User).save(user);
  }
}
