import 'source-map-support/register';
process.env.NODE_ENV = 'e2e';
